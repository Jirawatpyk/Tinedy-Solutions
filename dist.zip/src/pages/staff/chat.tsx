// Staff chat page - reuses the same component as admin
export { AdminChat as StaffChat } from '../admin/chat'
